using System.Collections;
using AI.Nodes;
using System.Collections.Generic;
using UnityEngine;

public class Seek : ActionNode
{
    protected override void OnStart()
    {
       
    }
    protected override State OnUpdate()
    {
        


        return State.Running;
    }
    protected override void OnStop()
    {
       
    }
}
